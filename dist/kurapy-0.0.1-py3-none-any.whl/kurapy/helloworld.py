import numpy as np


def foo():
    return np.eye(3)
